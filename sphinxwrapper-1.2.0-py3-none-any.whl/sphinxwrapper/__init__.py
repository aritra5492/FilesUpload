"""
sphinxwrapper package
"""

from pocketsphinx import Decoder_default_config as DefaultConfig

from .pocketsphinx_wrap import PocketSphinx
from .config import *
